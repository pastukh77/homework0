.. Sun_prospect documentation master file, created by
   sphinx-quickstart on Mon May 25 15:07:03 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Sun_prospect's documentation!
========================================

.. automodule:: adt
   :members:

.. automodule:: flask_app
   :members:

.. automodule:: main
   :members:

.. automodule:: soup
   :members:

.. automodule:: wind
   :members:

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
